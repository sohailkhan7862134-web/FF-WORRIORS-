const tournaments = {
  "FULL MAP": [
    {name:"Full Map Tournament #1", entry:"₹35", reward:"₹28 / kill + ₹650 Booyah", status:"Demo"},
    {name:"Full Map Tournament #2", entry:"₹35", reward:"₹28 / kill + ₹650 Booyah", status:"Demo"}
  ],
  "LONWOLF 1 VS 1": [
    {name:"Lonwolf 1 VS 1 #1", entry:"₹50", reward:"₹80 winner", status:"Demo"}
  ],
  "CLASH SQUAD 2 VS 2": [
    {name:"Clash Squad 2 VS 2 #1", entry:"₹50", reward:"₹80 each for 2 winning players", status:"Demo"}
  ],
  "LONWOLF 2 VS 2": [
    {name:"Lonwolf 2 VS 2 #1", entry:"₹50", reward:"₹80 each for winning players", status:"Demo"}
  ]
};

function hideAll(){document.querySelectorAll("main section").forEach(s=>s.classList.add("hidden"))}
function goHome(){hideAll();document.getElementById("home").classList.remove("hidden")}
function openCategory(category){
  hideAll();
  document.getElementById("details").classList.remove("hidden");
  document.getElementById("categoryTitle").textContent=category;
  const list=document.getElementById("tournamentList");
  list.innerHTML="";
  (tournaments[category]||[]).forEach(t=>{
    const el=document.createElement("div");
    el.className="tournament";
    el.innerHTML=`<h3>${t.name}</h3><span class="tag">Entry ${t.entry}</span><p>${t.reward}</p><button class="back" onclick="demoJoin()">View / Join</button>`;
    list.appendChild(el);
  });
}
function demoJoin(){alert("Demo only: payment/joining is not connected yet.")}
function showWallet(){hideAll();document.getElementById("wallet").classList.remove("hidden")}
function openSocial(which){
  const title=which==="instagram"?"Instagram":"YouTube";
  document.getElementById("modalTitle").textContent=title;
  document.getElementById("modalBody").innerHTML="<p>Social link will be connected here in the next step.</p>";
  document.getElementById("modal").classList.remove("hidden");
}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
