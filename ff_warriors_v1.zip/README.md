# FF Warriors V1

A Flutter prototype for a Free Fire community tournament app.

## Included
- Home screen
- 1v1 / 2v2 / Squad tournament browsing
- Tournament details
- Free registration form
- Player profile
- Mock notifications

## Run
1. Install Flutter and Android Studio.
2. Open this folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Run `flutter run`.

This V1 intentionally uses free-entry mock tournaments. Real-money entry fees, payouts, payment processing, and age/compliance checks should only be added after confirming applicable laws, platform/payment-provider rules, and adult/guardian involvement where required.
