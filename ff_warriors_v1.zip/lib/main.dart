import 'package:flutter/material.dart';

void main() => runApp(const FFWarriorsApp());

class FFWarriorsApp extends StatelessWidget {
  const FFWarriorsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FF Warriors',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF080B10),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFFC400),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class Tournament {
  final String title, mode, entry, prize, time;
  const Tournament(this.title, this.mode, this.entry, this.prize, this.time);
}

const tournaments = [
  Tournament('1v1 Solo Battle', '1v1', 'Free', 'Practice', '7:00 PM'),
  Tournament('2v2 Duo Clash', '2v2', 'Free', 'Practice', '8:00 PM'),
  Tournament('Squad War', 'Squad', 'Free', 'Practice', '9:00 PM'),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeTab(),
      const TournamentsTab(),
      const ProfileTab(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('FF WARRIORS',
            style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('No new notifications')),
            ),
            icon: const Icon(Icons.notifications_none),
          )
        ],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'Tournaments'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF292000), Color(0xFF11151D)],
            ),
            border: Border.all(color: const Color(0xFFFFC400), width: 1),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('PLAY • COMPETE • WIN',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              SizedBox(height: 8),
              Text('Join Free Fire community tournaments.',
                  style: TextStyle(color: Colors.white70)),
              SizedBox(height: 18),
              Text('JOIN THE BATTLE →',
                  style: TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text('Choose Mode',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Row(
          children: const [
            Expanded(child: ModeCard(icon: Icons.person, title: '1v1')),
            SizedBox(width: 10),
            Expanded(child: ModeCard(icon: Icons.group, title: '2v2')),
            SizedBox(width: 10),
            Expanded(child: ModeCard(icon: Icons.groups, title: 'Squad')),
          ],
        ),
        const SizedBox(height: 24),
        const Text('Upcoming Tournaments',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        ...tournaments.map((t) => TournamentCard(t: t)),
      ],
    );
  }
}

class ModeCard extends StatelessWidget {
  final IconData icon;
  final String title;
  const ModeCard({super.key, required this.icon, required this.title});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 18),
      child: Column(children: [
        Icon(icon, color: const Color(0xFFFFC400), size: 30),
        const SizedBox(height: 6),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      ]),
    ),
  );
}

class TournamentsTab extends StatelessWidget {
  const TournamentsTab({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: tournaments.map((t) => TournamentCard(t: t, detailed: true)).toList(),
  );
}

class TournamentCard extends StatelessWidget {
  final Tournament t;
  final bool detailed;
  const TournamentCard({super.key, required this.t, this.detailed = false});

  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleAvatar(
            backgroundColor: Color(0xFFFFC400),
            child: Icon(Icons.emoji_events, color: Colors.black),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(t.title,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
          Text(t.mode, style: const TextStyle(color: Color(0xFFFFC400))),
        ]),
        const SizedBox(height: 12),
        Text('Entry: ${t.entry}   •   Prize: ${t.prize}   •   ${t.time}',
            style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => DetailsPage(t: t))),
            child: const Text('VIEW & REGISTER'),
          ),
        )
      ]),
    ),
  );
}

class DetailsPage extends StatelessWidget {
  final Tournament t;
  const DetailsPage({super.key, required this.t});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Tournament Details')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t.title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        const SizedBox(height: 18),
        Text('Mode: ${t.mode}'),
        Text('Entry: ${t.entry}'),
        Text('Prize: ${t.prize}'),
        Text('Start: ${t.time}'),
        const SizedBox(height: 24),
        const Text('Rules', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('• No hacks or unfair tools\n• Follow game rules\n• Respect other players'),
        const Spacer(),
        SizedBox(width: double.infinity, child: FilledButton(
          onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const RegistrationPage())),
          child: const Text('REGISTER FOR FREE'),
        )),
      ]),
    ),
  );
}

class RegistrationPage extends StatefulWidget {
  const RegistrationPage({super.key});
  @override
  State<RegistrationPage> createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final name = TextEditingController();
  final uid = TextEditingController();
  @override
  void dispose() { name.dispose(); uid.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Registration')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Player Details', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 18),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Game Name', border: OutlineInputBorder())),
        const SizedBox(height: 14),
        TextField(controller: uid, decoration: const InputDecoration(labelText: 'Free Fire UID', border: OutlineInputBorder())),
        const SizedBox(height: 22),
        FilledButton(
          onPressed: () {
            if (name.text.trim().isEmpty || uid.text.trim().isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill both fields')));
              return;
            }
            showDialog(context: context, builder: (_) => AlertDialog(
              title: const Text('Registration Complete'),
              content: const Text('You are registered for this free-entry prototype tournament.'),
              actions: [TextButton(onPressed: () => Navigator.popUntil(context, (r) => r.isFirst), child: const Text('DONE'))],
            ));
          },
          child: const Text('CONFIRM REGISTRATION'),
        ),
      ],
    ),
  );
}

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const CircleAvatar(radius: 45, child: Icon(Icons.person, size: 48)),
      const SizedBox(height: 12),
      const Center(child: Text('Player Profile', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
      const SizedBox(height: 22),
      const ListTile(leading: Icon(Icons.emoji_events), title: Text('Tournament History'), trailing: Icon(Icons.chevron_right)),
      const ListTile(leading: Icon(Icons.bar_chart), title: Text('Results & Leaderboard'), trailing: Icon(Icons.chevron_right)),
      const ListTile(leading: Icon(Icons.settings), title: Text('Settings'), trailing: Icon(Icons.chevron_right)),
    ],
  );
}
